import java.util.ArrayList;

public class HistoriaClinica {

    private ArrayList<String> enfermedades = new ArrayList<String>();
    private ArrayList<String> discapacidades = new ArrayList<String>();
    private ArrayList<CitaMedica> citaMedicas= new ArrayList<>();
    private boolean esterilizado;

    public HistoriaClinica(ArrayList<String> enfermedades, ArrayList<String> discapacidades, boolean esterilizado) {
        this.enfermedades = enfermedades;
        this.discapacidades = discapacidades;
        this.esterilizado = esterilizado;
    }

    public void modificarHisotiaclinica(ArrayList<String> enfermedades,ArrayList<String> discapacidades,boolean esterilizado ){
        this.enfermedades=enfermedades;
        this.discapacidades=discapacidades;

        if (esterilizado=esterilizado)
            System.out.println("La mascota ya esta esterelizada");
        else {
            this.esterilizado = esterilizado;
        }


    }

    public void setEnfermedades(ArrayList<String> enfermedades) {
        this.enfermedades = enfermedades;
    }

    public void setDiscapacidades(ArrayList<String> discapacidades) {
        this.discapacidades = discapacidades;
    }

    public boolean isEsterilizado() {
        return esterilizado;
    }

    public void setEsterilizado(boolean esterilizado) {
        this.esterilizado = esterilizado;
    }

    public void getEnfermedades() {
        if (enfermedades.size() == 0){
            System.out.println("Este animal no tiene discapacidades");
        }else{
            for (int i = 0; i < enfermedades.size(); i++){
                System.out.println("\n"+ enfermedades.get(i));
            }
        }
    }


    public void getDiscapacidades() {
        if (discapacidades.size() == 0){
            System.out.println("Este animal no tiene discapacidades");
        }else{
            for (int i = 0; i < discapacidades.size(); i++){
                System.out.println("\n"+ discapacidades.get(i));
            }
        }
    }

}
