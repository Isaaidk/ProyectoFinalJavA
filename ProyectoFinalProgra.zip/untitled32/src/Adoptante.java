import java.util.ArrayList;


public class Adoptante {

    // -----------------------------------------------------------------
    // Atributos
    // -----------------------------------------------------------------

    //Modela al adoptante
    private String CI;
    private String nombre;
    private String apellido;
    private String telefono;
    private String email;
    private int edad;
    private String domicilio;
    private double tamanoDom;
    private ArrayList<Solicitud> solicitudes;
    //Constructor


    public Adoptante(String CI, String nombre, String apellido, String telefono, String email, int edad, String domicilio, double tamanoDom, ArrayList<Donacion> donaciones, ArrayList<Solicitud> solicitudes) {
        this.CI = CI;
        this.nombre = nombre;
        this.apellido = apellido;
        this.telefono = telefono;
        this.email = email;
        this.edad = edad;
        this.domicilio = domicilio;
        this.tamanoDom = tamanoDom;

        this.solicitudes = solicitudes;
        solicitudes=new ArrayList<Solicitud>();

    }

    //metodos
    public String getCI() {
        return CI;
    }
    public void setCI(String CI) {
        this.CI = CI;
    }
    public String getNombre() {
        return nombre;
    }
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    public String getApellido() {
        return apellido;
    }
    public void setApellido(String apellido) {
        this.apellido = apellido;
    }
    public String getTelefono() {
        return telefono;
    }
    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }
    public String getEmail() {
        return email;
    }
    public void setEmail(String email) {
        this.email = email;
    }
    public int getEdad() {
        return edad;
    }
    public void setEdad(int edad) {
        this.edad = edad;
    }
    public ArrayList<Solicitud> getSolicitudes() {
        return solicitudes;
    }
    public void setSolicitudes(ArrayList<Solicitud> solicitudes) {
        this.solicitudes = solicitudes;
    }
    public String getDomicilio() {
        return domicilio;
    }
    public void setDomicilio(String domicilio) {
        this.domicilio = domicilio;
    }
    public double getTamanoDom() {
        return tamanoDom;
    }
    public void setTamanoDom(double tamanoDom) {
        this.tamanoDom = tamanoDom;
    }









    public void asignarSolicitud(int solicitud){
        //acabasr clase solicitud y agregar metodos

    }
    public void asignarMascota(int identificadorMascotas){



    }

    public void actualizarDatos(String domicilio, double tamanoDom) {

        this.domicilio = domicilio;
        this.tamanoDom = tamanoDom;
    }



}
