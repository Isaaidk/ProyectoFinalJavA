import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        ArrayList<Adoptante> adoptantes = new ArrayList<Adoptante>();
        Scanner sc = new Scanner(System.in);
        ArrayList<Donante>donacions = new ArrayList<Donante>();






        int opc;

        while(true) {
            System.out.println("Ingrese una opcion");
            System.out.println("1. Ingresar datos de aspirante de mascota");
            System.out.println("2. Modificar datos de adoptante de mascota");
            System.out.println("3. Eliminar dueño de mascota");
            System.out.println("4. Obtener datos de dueño");
            System.out.println("5. Ingresar donacion");
            System.out.println("6. Consultar Donaciones (por metodo de pago)");
            System.out.println("7. Consultar donaciones (por fecha)");
            System.out.println("8. Consultar donaciones (por monto)");
            System.out.println("9. Ver todas las donaciones");
            System.out.println("10. Salir");

            opc = Integer.parseInt(sc.nextLine());

            switch (opc){
                case 1:
                    ingresarDonante(donacions,sc);




                    break;


                case 2:

                    break;

                case 3:
                    System.out.println("Ingrese el CI del adoptante a eliminar:");
                    String ciEliminar = sc.nextLine();
                    Adoptante adoptanteAEliminar = buscarAdoptantesPorCedula(adoptantes, ciEliminar);
                    if (adoptanteAEliminar != null) {
                        adoptantes.remove(adoptanteAEliminar);
                    } else {
                        System.out.println("Adoptante no encontrado.");
                    }
                    break;

                case 4:
                    System.out.println("Ingrese el CI del adoptante cuyos datos desea obtener:");
                    String ciBuscar = sc.nextLine();
                    Adoptante adoptanteABuscar = buscarAdoptantesPorCedula(adoptantes, ciBuscar);
                    if (adoptanteABuscar != null) {
                        System.out.println("Datos del Adoptante:");
                        System.out.println(adoptanteABuscar.toString());
                    } else {
                        System.out.println("Adoptante no encontrado.");
                    }
                    break;
                case 5:




                    break;


                case 6:
                    break;

                case 7:
                    break;


                case 8:
                    break;


                case 9:
                    break;

                case 10:
                    System.out.println("Saliendo...");
                    System.exit(0);
                    break;

                default:
                    System.out.println("Ingrese una opción válida");
            }
        }
    }



    public static void ingresarDonante(ArrayList<Donante>donante,Scanner sc){
        System.out.println("Ingrese el numero de cedula");
        String CI = sc.next();
        System.out.println("Ingrese el nombre");
        String nombre = sc.next();
        System.out.println("Ingrese el apellido");
        String apellido = sc.next();
        System.out.println("Ingrese el telefono");
        String telefono = sc.next();
        System.out.println("Ingrese el email");
        String email = sc.next();
        System.out.println("Ingrese el monto de donacion");
        double monto = sc.nextDouble();
        Donante nuevodonante= new Donante(CI,nombre,apellido,telefono,email,monto);
        donante.add(nuevodonante);





    }




    private static Adoptante buscarAdoptantesPorCedula(ArrayList<Adoptante> adoptantes, String cedula) {
        for (Adoptante adoptante : adoptantes) {
            if (adoptante.getCI().equals(cedula)) {
                return adoptante;
            }
        }
        return null;
    }
}