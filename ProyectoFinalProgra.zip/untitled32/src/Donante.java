import java.util.ArrayList;
import java.util.Scanner;

public class Donante {

    private String CI;
    private String nombre;
    private String apellido;
    private String telefono;
    private String email;
    private double monto;
    private ArrayList<Donacion> donaciones;

    public Donante(String CI, String nombre, String apellido, String telefono, String email, double monto) {
        this.CI = CI;
        this.nombre = nombre;
        this.apellido = apellido;
        this.telefono = telefono;
        this.email = email;
        this.monto = monto;
        this.donaciones = new ArrayList<>();
    }



    public double getMonto() {
        return monto;
    }

    public void setMonto(double monto) {
        this.monto = monto;
    }

    public ArrayList<Donacion> getDonaciones() {
        return donaciones;
    }

    public void setDonaciones(ArrayList<Donacion> donaciones) {
        this.donaciones = donaciones;
    }

    public String getCI() {
        return CI;
    }

    public void setCI(String CI) {
        this.CI = CI;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getEmail() {
        return email;
    }


    public void registrarDonacion(Donacion nuevaDonacion) {
        donaciones.add(nuevaDonacion);
    }

    public void setEmail(String email) {
        if (validarFormatoEmail(email)) {
            this.email = email;
        } else {
            System.out.println("Correo electrónico mal ingresado. Debe contener '@' y '.com'.");
            solicitarNuevoEmail();
        }
    }

    private boolean validarFormatoEmail(String email) {
        return email.contains("@") && email.contains(".com");
    }

    private void solicitarNuevoEmail() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Ingrese el correo electrónico nuevamente: ");
        String nuevoEmail = scanner.next();
        setEmail(nuevoEmail);
    }














}
