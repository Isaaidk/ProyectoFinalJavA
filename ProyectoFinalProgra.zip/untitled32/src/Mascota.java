import java.util.ArrayList;
public class Mascota {

    private String ID;
    private String nombre;
    private String tipoAnimal;
    private String raza;
    private String tamano;
    private int edad;
    private double peso;

    private ArrayList<HistoriaClinica> historiaClinicas;
    private ArrayList<CitaMedica> citaMedicas;


    public Mascota(String ID, String nombre, String tipoAnimal, String raza, String tamano, int edad, double peso, ArrayList<HistoriaClinica> historiaClinica, ArrayList<CitaMedica> citaMedicas) {
        this.ID = ID;
        this.nombre = nombre;
        this.tipoAnimal = tipoAnimal;
        this.raza = raza;
        this.tamano = tamano;
        this.edad = edad;
        this.peso = peso;
        this.historiaClinicas = historiaClinicas;
        this.citaMedicas =citaMedicas;
    }

    public String getID() {
        return ID;
    }

    public void setID(String ID) {
        this.ID = ID;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getTipoAnimal() {
        return tipoAnimal;
    }

    public void setTipoAnimal(String tipoAnimal) {
        this.tipoAnimal = tipoAnimal;
    }

    public String getRaza() {
        return raza;
    }

    public void setRaza(String raza) {
        this.raza = raza;
    }

    public String getTamano() {
        return tamano;
    }

    public void setTamano(String tamano) {
        this.tamano = tamano;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public double getPeso() {
        return peso;
    }

    public void setPeso(double peso) {
        this.peso = peso;
    }

    public ArrayList<HistoriaClinica> getHistoriaClinicas() {
        return historiaClinicas;
    }

    public void setHistoriaClinicas(ArrayList<HistoriaClinica> historiaClinicas) {
        this.historiaClinicas = historiaClinicas;
    }




}
